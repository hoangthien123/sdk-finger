# U20-BF_Android_Bluetooth_Demo
U20-BF Demo using Android Studio

This project was buil with Android Studio v2.2.2
https://sites.google.com/a/android.com/tools/download/studio/builds/2-2-2