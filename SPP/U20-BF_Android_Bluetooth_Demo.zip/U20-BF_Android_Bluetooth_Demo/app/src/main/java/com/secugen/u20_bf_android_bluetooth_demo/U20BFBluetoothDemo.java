package com.secugen.u20_bf_android_bluetooth_demo;

import com.secugen.fmssdk.*;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.util.Log;
import android.content.Intent;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import static com.secugen.u20_bf_android_bluetooth_demo.U20BFDemoService.PACKET_SIZE;

class WSQInfoClass {
    int width = 0;
    int height = 0;
    int pixelDepth = 0;
    int ppi = 0;
    int lossyFlag = 0;
}

public class U20BFBluetoothDemo extends AppCompatActivity {

    // Debugging
    private static final String TAG = "U20BF Demo";
    private static final boolean D = true;

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;

    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;

    // Layout Views
    private TextView mTitle;
    private ListView mConversationView;
    private EditText mOutEditText;
    private Button mButtonPair;
    private Button mButtonGetFirmwareVersion;
    private Button mButtonRegister1;
    private Button mButtonRegister2;
    private Button mButtonVerify;
    private Button mButtonDelete;
    private Button mButtonIdentify;
    private Button mButtonCapture;

    private TextView mTextViewStatus;
    private ImageView mImageViewResult;
    private ImageView mImageViewFingerprint;

    private CheckBox mCheckWSQ;

    // Name of the connected device
    private String mConnectedDeviceName = null;
    // Array adapter for the conversation thread
    private ArrayAdapter<String> mConversationArrayAdapter;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private U20BFDemoService mU20BFService = null;

    // libsgwsq-jni.so
    static {
        System.loadLibrary("sgwsq-jni");
    }

    public native byte[] jniSgWSQDecode(WSQInfoClass WSQInfoClass, byte[] wsqImage, int wsqImageLength);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");

        setContentView(R.layout.activity_u20bf_bluetooth_demo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set up the custom title
        mTitle = (TextView) findViewById(R.id.title_left_text);
        mTitle.setText(R.string.app_name);
        this.mTextViewStatus = (TextView) findViewById(R.id.textViewStatus);

        mCheckWSQ = (CheckBox) findViewById(R.id.checkBoxWSQFormat);

        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");

        // If BT is not on, request that it be enabled.
        // setupU20BF() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
            // Otherwise, setup the chat session
        } else {
            if (mU20BFService == null) setupU20BF();
        }
    }

    @Override
    public synchronized void onResume() {
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");

        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (mU20BFService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mU20BFService.getState() == U20BFDemoService.STATE_NONE) {
                // Start the Bluetooth chat services
                mU20BFService.start();
            }
        }
        mTextViewStatus.setText("Please Click Connect");
    }

    //////////////////////////////////////////////////////////////////////////
    //Display byte array as hex string
    private static String bytesToHexString(byte[] bytes){
        StringBuilder sb = new StringBuilder();
        for(byte b : bytes){
            sb.append(String.format("%02x ", b&0xff));
        } return sb.toString();
    }

    //Display byte array as hex string
    private static String bytesToHexString(byte[] bytes, int sizes){
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < sizes; i++){
            sb.append(String.format("%02x", bytes[i]&0xff));
        }
        return sb.toString();
    }

    //Display short as hex string
    private static String shortToHexString(short data){
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("%02X", (data >> 8)&0xff));
        sb.append(String.format("%02X", (data     )&0xff));

        return sb.toString();
    }

    // Assume a number less than four digits.
    private static int getStringToValidUserID(String s){
        int strLen = s.length();
        int nValidUserID = 0, pos = 0;
        if (strLen%2 !=0 ) // fail if odd
            return -1;

        for (int i = 0; i < strLen; i+= 2) {
            nValidUserID = (nValidUserID << (pos*8)) | ((Character.digit(s.charAt(i),16) << 4) + Character.digit(s.charAt(i+1), 16));
            pos++;
        }

        return nValidUserID;
    }

    //////////////////////////////////////////////////////////////////////////
    //Setup controls and event handlers
    private void setupU20BF() {
        Log.d(TAG, "setupU20BF()");

        // Initialize the array adapter for the conversation thread
        mConversationArrayAdapter = new ArrayAdapter<String>(this, R.layout.message);
        mConversationView = (ListView) findViewById(R.id.in);
        mConversationView.setAdapter(mConversationArrayAdapter);


        // Initialize the compose field with a listener for the return key
        mOutEditText = (EditText) findViewById(R.id.edit_text_out);
        mOutEditText.setOnEditorActionListener(mWriteListener);

        //////////////////////////////////////////////////////////////////////////
        //Pair with U20-BF
        mButtonPair = (Button) findViewById(R.id.buttonPair);
        mButtonPair.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent serverIntent = new Intent(getApplicationContext(), DeviceListActivity.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
            }
        });

        //////////////////////////////////////////////////////////////////////////
        //Get Firmware Version
        mButtonGetFirmwareVersion = (Button) findViewById(R.id.buttonGetFirmwareVersion);
        mButtonGetFirmwareVersion.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewResult.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("Get Firmware Version");
                mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdGetVersion()));
                mU20BFService.write(FMSAPI.cmdGetVersion());
            }
        });

        //////////////////////////////////////////////////////////////////////////
        //Register User - Capture fingerprint 1
        mButtonRegister1 = (Button) findViewById(R.id.buttonRegister1);
        mButtonRegister1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewResult.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("+++");
                mConversationArrayAdapter.add("Register Capture 1");
                TextView view = (TextView) findViewById(R.id.edit_text_out);
                String userID = view.getText().toString();
                if (userID.length() == 4)
                {
                    int validUserID = getStringToValidUserID(userID);
                    if (validUserID != -1) {
                        boolean isAdmin = false;
                        mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPRegisterStart(validUserID, isAdmin)));
                        mU20BFService.write(FMSAPI.cmdFPRegisterStart(validUserID, isAdmin));
                    }
                    else {
                        mConversationArrayAdapter.add("User ID digits should be an even number, and only numerals are allowed for each digit.");
                        mTextViewStatus.setText("User ID digits should be an even number, and only numerals are allowed for each digit.");
                    }
                }
                else {
                    mConversationArrayAdapter.add("Please enter a four-digit number.");
                    mTextViewStatus.setText("Please enter a four-digit number.");
                }
            }
        });

        //////////////////////////////////////////////////////////////////////////
        //Register User - Capture fingerprint 2 and finalize
        mButtonRegister2 = (Button) findViewById(R.id.buttonRegister2);
        mButtonRegister2.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewResult.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("Register Capture 2");
                mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPRegisterEnd()));
                mU20BFService.write(FMSAPI.cmdFPRegisterEnd());
            }
        });


        //////////////////////////////////////////////////////////////////////////
        //Verify user
        mButtonVerify = (Button) findViewById(R.id.buttonVerify);
        mButtonVerify.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewResult.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("+++");
                mConversationArrayAdapter.add("Verify");
                TextView view = (TextView) findViewById(R.id.edit_text_out);
                String userID = view.getText().toString();
                if (userID.length() == 4)
                {
                    int validUserID = getStringToValidUserID(userID);
                    if (validUserID != -1) {
                        mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPVerify(validUserID)));
                        mU20BFService.write(FMSAPI.cmdFPVerify(validUserID));
                    }
                    else {
                        mConversationArrayAdapter.add("User ID digits should be an even number, and only numerals are allowed for each digit.");
                        mTextViewStatus.setText("User ID digits should be an even number, and only numerals are allowed for each digit.");
                    }
                }
                else
                    mConversationArrayAdapter.add("Please enter a four-digit number.");
            }
        });

        //////////////////////////////////////////////////////////////////////////
        //Delete user
        mButtonDelete = (Button) findViewById(R.id.buttonDelete);
        mButtonDelete.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewResult.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("+++");
                mConversationArrayAdapter.add("Delete User");
                TextView view = (TextView) findViewById(R.id.edit_text_out);
                String userID = view.getText().toString();
                if (userID.length() == 4)
                {
                    int validUserID = getStringToValidUserID(userID);
                    if (validUserID != -1) {
                        mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPDelete(validUserID)));
                        mU20BFService.write(FMSAPI.cmdFPDelete(validUserID));
                    }
                    else {
                        mConversationArrayAdapter.add("User ID digits should be an even number, and only numerals are allowed for each digit.");
                        mTextViewStatus.setText("User ID digits should be an even number, and only numerals are allowed for each digit.");
                    }
                }
                else
                    mConversationArrayAdapter.add("Please enter a four-digit number.");
            }
        });


        //////////////////////////////////////////////////////////////////////////
        //Identify User
        mButtonIdentify = (Button) findViewById(R.id.buttonIdentify);
        mButtonIdentify.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewResult.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("+++");
                mConversationArrayAdapter.add("Identify User");
                mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPIdentify()));
                mU20BFService.write(FMSAPI.cmdFPIdentify());
            }
        });

        //////////////////////////////////////////////////////////////////////////
        //Capture
        mButtonCapture = (Button) findViewById(R.id.buttonCapture);
        mButtonCapture.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImageViewFingerprint.setImageResource(R.drawable.status_blank);
                mConversationArrayAdapter.add("+++");
                if (mCheckWSQ.isChecked()) {
                    mConversationArrayAdapter.add("Capture use WSQ format");
                    mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPCaptureUseWSQ()));
                    mU20BFService.write(FMSAPI.cmdFPCaptureUseWSQ());
                } else {
                    mConversationArrayAdapter.add("Capture");
                    mConversationArrayAdapter.add("SEND: " + bytesToHexString(FMSAPI.cmdFPCapture()));
                    mU20BFService.write(FMSAPI.cmdFPCapture());
                }
            }
        });

        mImageViewResult = (ImageView) findViewById(R.id.imageViewResult);
        mImageViewFingerprint = (ImageView) findViewById(R.id.imageViewFingerprint);

        // Initialize the BluetoothChatService to perform bluetooth connections
        mU20BFService = new U20BFDemoService(this, mHandler);

        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
    }

    @Override
    public synchronized void onPause() {
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }

    @Override
    public void onStop() {
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Stop the Bluetooth chat services
        if (mU20BFService != null) mU20BFService.stop();
        if(D) Log.e(TAG, "--- ON DESTROY ---");
    }

    private void ensureDiscoverable() {
        if(D) Log.d(TAG, "ensure discoverable");
        if (mBluetoothAdapter.getScanMode() !=
                BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }

    /**
     * Sends a message.
     * @param message  A string of text to send.
     */
    private void sendMessage(String message) {
        // Check that we're actually connected before trying anything
        if (mU20BFService.getState() != U20BFDemoService.STATE_CONNECTED) {
            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }
        mConversationArrayAdapter.add("Out:  " + message);

        // Check that there's actually something to send
        if (message.length() > 0) {
            // Get the message bytes and tell the BluetoothChatService to write
            byte[] command = message.getBytes();
            switch(command[0])
            {
                case 'r':
                case 'R':
                    if (command.length > 1)
                    {
                        String str = new String(command,1,command.length-1);
                        boolean isAdmin = false;
                        mU20BFService.write(FMSAPI.cmdFPRegisterStart(Integer.parseInt(str),isAdmin));
                    }
                    else
                        mConversationArrayAdapter.add("Please enter user ID");
                    break;
                case 'f':
                case 'F':
                    mU20BFService.write(FMSAPI.cmdFPRegisterEnd());
                    break;
                case 'd':
                case 'D':
                    if (command.length > 1)
                    {
                        String str = new String(command,1,command.length-1);
                        mU20BFService.write(FMSAPI.cmdFPDelete(Integer.parseInt(str)));
                    }
                    else
                        mConversationArrayAdapter.add("Please enter user ID");
                    break;
                case 'i':
                case 'I':
                    mU20BFService.write(FMSAPI.cmdFPIdentify());
                    break;
                case 'v':
                case 'V':
                    if (command.length > 1)
                    {
                        String str = new String(command,1,command.length-1);
                        mU20BFService.write(FMSAPI.cmdFPVerify(Integer.parseInt(str)));
                    }
                    break;

                default:;
                    mConversationArrayAdapter.add("Unrecognized command:  " + command[0]);
                    break;
            }

            // Reset out string buffer to zero and clear the edit text field
            mOutStringBuffer.setLength(0);
            mOutEditText.setText(mOutStringBuffer);
        }
    }

    // The action listener for the EditText widget, to listen for the return key
    private TextView.OnEditorActionListener mWriteListener =
            new TextView.OnEditorActionListener() {
                public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
                    // If the action is a key-up event on the return key, send the message
                    if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
                        String message = view.getText().toString();
                        sendMessage(message);
                    }
                    if(D) Log.i(TAG, "END onEditorAction");
                    return true;
                }
            };

    // The Handler that gets information back from the BluetoothChatService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_STATE_CHANGE:
                    if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                    switch (msg.arg1) {
                        case U20BFDemoService.STATE_CONNECTED:
                            //mTitle.setText(R.string.title_connected_to);
                            //mTitle.append(mConnectedDeviceName);
                            mConversationArrayAdapter.clear();
                            mConversationArrayAdapter.add("Succesfully connected to Unity20");
                            mTextViewStatus.setText("Succesfully connected to Unity20");

                            break;
                        case U20BFDemoService.STATE_CONNECTING:
                            mTitle.setBackgroundColor(Color.YELLOW);
                            mTitle.setText(R.string.title_connecting);
                            break;
//                        case U20BFDemoService.STATE_LISTEN:
                        case U20BFDemoService.STATE_NONE:
                            mTitle.setText(R.string.title_not_connected);
                            break;
                    }
                    break;
                case MESSAGE_WRITE:
                    byte[] writeBuf = (byte[]) msg.obj;
                    // construct a string from the buffer
                    String writeMessage = new String(writeBuf);
                    //String writeMessage = "To BT";
                    //mConversationArrayAdapter.add("Me:  " + writeMessage);
                    break;
                case MESSAGE_READ:
                    byte[] readBuf = (byte[]) msg.obj;
                    // construct a string from the valid bytes in the buffer
                    //String readMessage = new String(readBuf, 0, msg.arg1);
                    //String readMessage = "From BT";
                    //mConversationArrayAdapter.add(mConnectedDeviceName+":  " + readMessage);

                    if (readBuf[1] != FMSAPI.CMD_FP_CAPTURE) {
                        mConversationArrayAdapter.add("RECEIVE: " + bytesToHexString(readBuf));
                    }
                    mConversationArrayAdapter.add(mConnectedDeviceName + ":  " + FMSAPI.parseResponse(readBuf));
                    mTextViewStatus.setText(mConnectedDeviceName + ":  " + FMSAPI.parseResponse(readBuf));

                    FMSHeader header = new FMSHeader(readBuf);
                    FMSData data = new FMSData(readBuf);
                    switch(readBuf[1])
                    {
                        case FMSAPI.CMD_FP_VERIFY:
                            //Bitmap bImage;
                            switch(readBuf[10])
                            {
                                case FMSAPI.ERR_NONE:
                                    mTextViewStatus.setText(new String("User " + shortToHexString(header.pkt_param1) + " verified. Score:[" + header.pkt_param2 + "]"));
                                    mImageViewResult.setImageResource(R.drawable.status_recognized_48dp);
                                    break;
                                case FMSAPI.ERR_VERIFY_FAILED:
                                    mTextViewStatus.setText(new String("User " + shortToHexString(header.pkt_param1) + " not verified. Score:[" + header.pkt_param2 + "]"));
                                    mImageViewResult.setImageResource(R.drawable.status_not_recognized_48dp);
                                    break;
                                case FMSAPI.ERR_USER_NOT_FOUND:
                                    mTextViewStatus.setText(new String("User " + shortToHexString(header.pkt_param1) + " not found."));
                                    mImageViewResult.setImageResource(R.drawable.status_error_48dp);
                                    break;
                                default:
                                    mTextViewStatus.setText(new String("Error: [" + Integer.toHexString((int) readBuf[10])  + "]"));
                                    mImageViewResult.setImageResource(R.drawable.status_error_48dp);
                            }
                            break;
                        case FMSAPI.CMD_FP_IDENTIFY:
                            switch(readBuf[10])
                            {
                                case FMSAPI.ERR_NONE:
                                    mTextViewStatus.setText(new String("User " + ((data.d_length > 0) ? bytesToHexString(data.get(), data.d_length): shortToHexString(header.pkt_param1)) + " identified. Score:[" + header.pkt_param2 + "]" ));
                                    mImageViewResult.setImageResource(R.drawable.status_recognized_48dp);
                                    break;
                                case FMSAPI.ERR_IDENTIFY_FAILED:
                                    mTextViewStatus.setText(new String("User not found."));
                                    mImageViewResult.setImageResource(R.drawable.status_not_recognized_48dp);
                                    break;
                                default:
                                    mTextViewStatus.setText(new String("Error: [" + Integer.toHexString((int) readBuf[10])  + "]"));
                            }
                            break;
                        case FMSAPI.CMD_FP_CAPTURE:
                            switch(readBuf[10])
                            {
                                case FMSAPI.ERR_NONE:
                                    mImageViewResult.setImageResource(R.drawable.status_recognized_48dp);
                                    if (mCheckWSQ.isChecked()) {
                                        WSQInfoClass myInfo = new WSQInfoClass();
                                        byte[] imgBuf = data.get();
                                        byte[] rtValue = jniSgWSQDecode(myInfo, imgBuf, data.d_length);

                                        mConversationArrayAdapter.add("WSQ Information: ");
                                        mConversationArrayAdapter.add("     width: " + myInfo.width + "   height: " + myInfo.height);
                                        mConversationArrayAdapter.add("     ppi: " + myInfo.ppi + "   pixeldepth: " + myInfo.pixelDepth);
                                        mConversationArrayAdapter.add("     bitrate: " + "15:1 (0.75)" );
                                        mConversationArrayAdapter.add("     wsq size: " + data.d_length);

                                        FMSImage Img = new FMSImage(rtValue, myInfo.width*myInfo.height);
                                        mImageViewFingerprint.setImageBitmap(Img.get());
                                    } else {
                                        FMSImage Img = new FMSImage(data.get(), data.d_length);
                                        mConversationArrayAdapter.add("Image Information: ");
                                        mConversationArrayAdapter.add("     width: " + Img.getmWidth() + "   height: " + Img.getmHeight());
                                        mConversationArrayAdapter.add("     image size: " + Img.getmWidth()*Img.getmHeight());

                                        mImageViewFingerprint.setImageBitmap(Img.get());
                                    }
                                    break;
                                default:
                                    mTextViewStatus.setText(new String("Error: [" + Integer.toHexString((int) readBuf[10])  + "]"));
                            }
                            break;
                    }

                    break;
                case MESSAGE_DEVICE_NAME:
                    // save the connected device's name
                    mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                    Toast.makeText(getApplicationContext(), "Connected to "
                            + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                    mTitle.setText(" Connected to " + mConnectedDeviceName);
                    mTitle.setBackgroundColor(Color.GREEN);
                    break;
                case MESSAGE_TOAST:
                    Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
                            Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(D) Log.d(TAG, "onActivityResult " + resultCode);
        Log.d(TAG, "requestCode " + requestCode);
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE:
                // When DeviceListActivity returns with a device to connect
                Log.d(TAG, "REQUEST_CONNECT_DEVICE");
                if (resultCode == Activity.RESULT_OK) {
                    // Get the device MAC address
                    String address = data.getExtras()
                            .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
                    // Get the BLuetoothDevice object
                    BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
                    // Attempt to connect to the device
                    mU20BFService.connect(device);
                }
                break;
            case REQUEST_ENABLE_BT:
                Log.d(TAG, "REQUEST_ENABLE_BT");
                // When the request to enable Bluetooth returns
                if (resultCode == Activity.RESULT_OK) {
                    // Bluetooth is now enabled, so set up a chat session
                    setupU20BF();
                } else {
                    // User did not enable Bluetooth or an error occured
                    Log.d(TAG, "BT not enabled");
                    Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.scan:
                // Launch the DeviceListActivity to see devices and do scan
                Intent serverIntent = new Intent(this, DeviceListActivity.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
                return true;
            case R.id.discoverable:
                // Ensure this device is discoverable by others
                ensureDiscoverable();
                return true;
            case R.id.action_settings:
                // Ensure this device is discoverable by others
                return true;
        }
        return false;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_u20bf_bluetooth_demo, menu);
        return true;
    }

}
